﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FinalIP.Models
{
    public class ContactTable
    {
        [Key]
        public int ContactId { get; set; }

        [Required(ErrorMessage = "Please enter {0}")]
        [Display(Name = "First Name")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Please enter {0}")]
        [Display(Name = "Last Name")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Please enter {0}")]
        public string Phone { get; set; }

        [Required(ErrorMessage = "Please enter {0}")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Please enter {0}")]
        public string Category { get; set; }
        public string Organization { get; set; }
    }
}
